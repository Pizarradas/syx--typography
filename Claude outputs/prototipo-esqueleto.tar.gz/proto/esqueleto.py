"""Prototipo: letras desde el esqueleto con una plumilla rectangular de ángulo fijo.

La suma de Minkowski de un rectángulo de orientación fija a lo largo de una cúbica es
EXACTA en Bézier, sin ajuste: mientras la tangente no sea paralela a un canto de la
plumilla, el vértice que toca cada borde es siempre el mismo, así que cada borde es el
propio tramo de esqueleto TRASLADADO por ese vértice (una cúbica trasladada sigue siendo
una cúbica). Basta con:
  1. partir cada cúbica donde su tangente es paralela a un canto (ecuación cuadrática);
  2. para cada pieza, la región entre las traslaciones por el vértice izquierdo y el
     derecho, cerrada por la diagonal de la plumilla (interior a ella);
  3. añadir la plumilla en cada extremo de pieza (inicio, cambios de vértice y final).
La unión de esas regiones es exactamente el área barrida. Las regiones se guardan como
contornos solapados (compatibles entre pesos por construcción: la partición depende solo
del esqueleto y del ángulo, no del tamaño de la plumilla) y se unen al exportar.
"""
import math

import pathops
from fontTools.misc.bezierTools import solveQuadratic


class Plumilla:
    """Rectángulo de largo W (canto largo a alfa grados) y grueso t."""

    def __init__(self, W, t, alfa):
        self.W, self.t, self.alfa = W, t, alfa
        u = (math.cos(math.radians(alfa)), math.sin(math.radians(alfa)))
        v = (-u[1], u[0])
        self.u, self.v = u, v
        self.vert = [(su * W / 2 * u[0] + sv * t / 2 * v[0], su * W / 2 * u[1] + sv * t / 2 * v[1])
                     for su, sv in ((1, 1), (-1, 1), (-1, -1), (1, -1))]  # antihorario

    @classmethod
    def por_asta(cls, asta, fino, alfa):
        """Plumilla cuyo trazo vertical mide asta y el trazo paralelo al canto, fino."""
        a = math.radians(alfa)
        return cls((asta - fino * math.sin(a)) / math.cos(a), fino, alfa)

    @property
    def medio_x(self):  # semiextensión horizontal = medio grosor de un trazo vertical
        return max(p[0] for p in self.vert)

    @property
    def medio_y(self):  # semiextensión vertical = medio grosor de un trazo horizontal
        return max(p[1] for p in self.vert)

    def apoyo(self, n):
        return max(self.vert, key=lambda p: p[0] * n[0] + p[1] * n[1])

    def rect(self, c):
        return [("l", (c[0] + p[0], c[1] + p[1])) for p in self.vert]


# -- cúbicas -------------------------------------------------------------------------
def _lerp(a, b, t):
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)


def partir(seg, t):
    if len(seg) == 2:
        m = _lerp(seg[0], seg[1], t)
        return (seg[0], m), (m, seg[1])
    p0, p1, p2, p3 = seg
    a, b, c = _lerp(p0, p1, t), _lerp(p1, p2, t), _lerp(p2, p3, t)
    d, e = _lerp(a, b, t), _lerp(b, c, t)
    m = _lerp(d, e, t)
    return (p0, a, d, m), (m, e, c, p3)


def tangente(seg, t):
    if len(seg) == 2:
        return (seg[1][0] - seg[0][0], seg[1][1] - seg[0][1])
    p0, p1, p2, p3 = seg
    m = 1 - t
    return tuple(3 * m * m * (p1[i] - p0[i]) + 6 * m * t * (p2[i] - p1[i]) + 3 * t * t * (p3[i] - p2[i]) for i in (0, 1))


def _cruz(a, b):
    return a[0] * b[1] - a[1] * b[0]


def cortes_paralelos(seg, dirs):
    """Parámetros donde la tangente es paralela a alguna dirección de dirs."""
    if len(seg) == 2:
        return []
    p0, p1, p2, p3 = seg
    a = (p1[0] - p0[0], p1[1] - p0[1])
    b = (p2[0] - p1[0], p2[1] - p1[1])
    c = (p3[0] - p2[0], p3[1] - p2[1])
    ts = set()
    for e in dirs:
        A, Bc, C = _cruz(a, e), _cruz(b, e), _cruz(c, e)
        for t in solveQuadratic(A - 2 * Bc + C, 2 * (Bc - A), A):
            if 1e-6 < t < 1 - 1e-6:
                ts.add(round(t, 12))
    return sorted(ts)


def trasladar(seg, v):
    return tuple((p[0] + v[0], p[1] + v[1]) for p in seg)


def invertir(seg):
    return tuple(reversed(seg))


# -- barrido --------------------------------------------------------------------------
def barrer(trazo, pl):
    """trazo: lista de segmentos ((p0,p1) recta o (p0,p1,p2,p3) cúbica) encadenados.
    Devuelve contornos (listas de segmentos cerrados) cuya unión es el área barrida."""
    piezas = []
    for seg in trazo:
        ts = cortes_paralelos(seg, (pl.u, pl.v))
        resto, t0 = seg, 0.0
        for t in ts:
            a, resto = partir(resto, (t - t0) / (1 - t0))
            piezas.append(a)
            t0 = t
        piezas.append(resto)
    contornos = []
    for pz in piezas:
        tg = tangente(pz, 0.5)
        n = (-tg[1], tg[0])
        vi, vd = pl.apoyo(n), pl.apoyo((-n[0], -n[1]))
        der, izq = trasladar(pz, vd), invertir(trasladar(pz, vi))
        contornos.append([der, (der[-1], izq[0]), izq, (izq[-1], der[0])])
    extremos = _unicos([piezas[0][0]] + [p[-1] for p in piezas])
    for c in extremos:
        r = [(c[0] + p[0], c[1] + p[1]) for p in pl.vert]
        contornos.append([(r[i], r[(i + 1) % 4]) for i in range(4)])
    return [_antihorario(c) for c in contornos]


def _unicos(pts, eps=1e-6):
    out = []
    for p in pts:
        if not any(math.dist(p, q) < eps for q in out):
            out.append(p)
    return out


def _path(contornos):
    p = pathops.Path()
    dibujar(contornos, p.getPen())
    return p


def _antihorario(cont):
    """Sentido antihorario según el área con signo de la región."""
    a = _area_green(cont)
    if a >= 0:
        return cont
    return [invertir(s) for s in reversed(cont)]


def _area_green(cont, n=32):
    tot = 0.0
    for s in cont:
        k = 1 if len(s) == 2 else n
        pts = [_eval(s, j / k) for j in range(k + 1)]
        tot += sum(pts[j][0] * pts[j + 1][1] - pts[j + 1][0] * pts[j][1] for j in range(k)) / 2
    return tot


def _eval(s, t):
    if len(s) == 2:
        return _lerp(s[0], s[1], t)
    m = 1 - t
    return tuple(m**3 * s[0][i] + 3 * m * m * t * s[1][i] + 3 * m * t * t * s[2][i] + t**3 * s[3][i] for i in (0, 1))


def dibujar(contornos, pen):
    """Dibuja contornos de segmentos; omite la recta final si cierra en el punto inicial
    (el cierre es implícito) y las rectas de longitud nula."""
    for c in contornos:
        segs = [s for s in c if not (len(s) == 2 and math.dist(s[0], s[1]) < 1e-9)]
        pen.moveTo(segs[0][0])
        ultimo = len(segs) - 1
        for i, s in enumerate(segs):
            if len(s) == 2:
                if i == ultimo and math.dist(s[1], segs[0][0]) < 1e-9:
                    continue
                pen.lineTo(s[1])
            else:
                pen.curveTo(s[1], s[2], s[3])
        pen.closePath()


def unir(contornos):
    return pathops.simplify(_path(contornos), clockwise=False)


# -- esqueletos de uso común ---------------------------------------------------------
def elipse(cx, cy, rx, ry, k):
    """Esqueleto cerrado de cuatro cuartos, empezando abajo y en sentido antihorario.
    k = tirador / radio (0,5523 es el círculo)."""
    b, d, t, i = (cx, cy - ry), (cx + rx, cy), (cx, cy + ry), (cx - rx, cy)
    return [(b, (cx + k * rx, cy - ry), (cx + rx, cy - k * ry), d),
            (d, (cx + rx, cy + k * ry), (cx + k * rx, cy + ry), t),
            (t, (cx - k * rx, cy + ry), (cx - rx, cy + k * ry), i),
            (i, (cx - rx, cy - k * ry), (cx - k * rx, cy - ry), b)]
