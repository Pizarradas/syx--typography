#!/usr/bin/env python3
"""Prototipo «esqueleto primero»: n o H O de Lacre en tres pesos.

Un glifo = esqueleto (pocos nodos) + plumilla + correcciones. El esqueleto se coloca
para que la TINTA caiga en las zonas: el borde de un trazo horizontal está a medio_y de
su eje, y el de uno vertical a medio_x (propiedades exactas de la plumilla). Los pesos
solo cambian la plumilla (y la anchura del dibujo): el esqueleto tiene la misma
estructura, así que los másteres son compatibles por construcción.

Uso: generador_esqueleto.py PROYECTO   (escribe sources/masters/*.ufo y export/*.ufo)
"""
import sys
from pathlib import Path

import pathops
import ufoLib2
from fontTools.pens.basePen import BasePen
from fontTools.designspaceLib import DesignSpaceDocument

sys.path.insert(0, str(Path(__file__).resolve().parent))
import esqueleto as E  # noqa: E402

CAP, X, REB, ALFA, K = 700, 470, 14, 20, 0.57
PESOS = {300: dict(asta=70, fino=24), 400: dict(asta=120, fino=38), 700: dict(asta=190, fino=58)}
ANCHO = dict(H=640, O=730, n=450, o=505)        # anchura de tinta en la Regular
LAT, LAT_F = 64, dict(H=(1.2, 1.2), O=(0.7, 0.7), o=(0.7, 0.7), n=(1.0, 0.8))


class ACubicas(BasePen):
    """Reenvía a otro pen elevando las cuadráticas a cúbicas (sin cambiar la forma)."""

    def __init__(self, destino):
        super().__init__(None)
        self.d = destino

    def _moveTo(self, p):
        self.d.moveTo(p)

    def _lineTo(self, p):
        self.d.lineTo(p)

    def _curveToOne(self, a, b, c):
        self.d.curveTo(a, b, c)

    def _closePath(self):
        self.d.closePath()


def ancho(nombre, asta):
    return ANCHO[nombre] + 0.6 * (asta - 120)  # más negro, algo más ancho


def esqueletos(p):
    """Devuelve {glifo: (plumilla, [trazos])}. Cada trazo es una lista de segmentos."""
    pl = E.Plumilla.por_asta(p["asta"], p["fino"], ALFA)
    plc = E.Plumilla.por_asta(p["asta"] * 1.08, p["fino"] * 1.04, ALFA)   # mayúsculas
    out = {}

    w = ancho("H", p["asta"])
    hx, hy = plc.medio_x, plc.medio_y
    out["H"] = (plc, [[((hx, hy), (hx, CAP - hy))],
                      [((w - hx, hy), (w - hx, CAP - hy))],
                      [((hx, CAP * 0.5), (w - hx, CAP * 0.5))]])

    for nombre, alto, plx in (("O", CAP, plc), ("o", X, pl)):
        w = ancho(nombre, p["asta"])
        out[nombre] = (plx, [E.elipse(w / 2, alto / 2, w / 2 - plx.medio_x, alto / 2 + REB - plx.medio_y, K)])

    w = ancho("n", p["asta"])
    hx, hy = pl.medio_x, pl.medio_y
    xr, ya, yt = w - hx, X * 0.42, X + REB - hy
    xm = (hx + xr) / 2
    out["n"] = (pl, [[((hx, hy), (hx, X - hy))],
                     [((hx, ya), (hx, ya + K * (yt - ya)), (xm - K * (xm - hx), yt), (xm, yt)),
                      ((xm, yt), (xm + K * (xr - xm), yt), (xr, ya + K * (yt - ya)), (xr, ya)),
                      ((xr, ya), (xr, hy))]])
    return out


def nodos_esqueleto(trazos):
    n = 0
    for tr in trazos:
        n += 1 + len(tr)          # nodo inicial + uno por segmento
        n += sum(2 for s in tr if len(s) == 4)  # tiradores
    return n


def escribir(u, nombre, cp, contornos, factores):
    g = u.newGlyph(nombre) if nombre not in u else u[nombre]
    g.clearContours()
    g.unicodes = [cp]
    E.dibujar(contornos, g.getPen())
    for c in g.contours:          # rejilla entera
        for pt in c.points:
            pt.x, pt.y = round(pt.x), round(pt.y)
    caja = pathops.Path()
    g.draw(caja.getPen())
    x0, _, x1, _ = caja.bounds
    li, ld = round(LAT * factores[0]), round(LAT * factores[1])
    g.move((li - round(x0), 0))
    g.width = li + round(x1) - round(x0) + ld
    return g


def main():
    proj = Path(sys.argv[1]).resolve()
    ds = DesignSpaceDocument.fromfile(next((proj / "sources").glob("*.designspace")))
    (proj / "export").mkdir(exist_ok=True)
    cps = dict(H=0x48, O=0x4F, n=0x6E, o=0x6F)
    for src in ds.sources:
        peso = int(src.location["Weight"])
        u = ufoLib2.Font.open(src.path)
        u.info.xHeight, u.info.capHeight = X, CAP
        exp = ufoLib2.Font()
        exp.info = u.info
        for nombre, (pl, trazos) in esqueletos(PESOS[peso]).items():
            contornos = [c for tr in trazos for c in E.barrer(tr, pl)]
            g = escribir(u, nombre, cps[nombre], contornos, LAT_F[nombre])
            g.lib["com.syx.esqueleto.nodos"] = nodos_esqueleto(trazos)
            # Copia unida (lo que sale al exportar), para medir.
            ge = exp.newGlyph(nombre)
            ge.unicodes, ge.width = [cps[nombre]], g.width
            p = pathops.Path()
            g.draw(p.getPen())
            pathops.simplify(p, clockwise=False).draw(ACubicas(ge.getPen()))
            for c in ge.contours:
                for pt in c.points:
                    pt.x, pt.y = round(pt.x), round(pt.y)
        if ".notdef" not in u:
            nd = u.newGlyph(".notdef"); pen = nd.getPen()
            for r in (((50, 0), (450, 0), (450, CAP), (50, CAP)), ((100, 50), (100, CAP - 50), (400, CAP - 50), (400, 50))):
                pen.moveTo(r[0]); [pen.lineTo(q) for q in r[1:]]; pen.closePath()
            nd.width = 500
        if "space" not in u:
            sp = u.newGlyph("space"); sp.unicodes = [0x20]; sp.width = 250
        u.lib["public.glyphOrder"] = [".notdef", "space", "H", "O", "n", "o"]
        u.save(overwrite=True)
        exp.save(proj / "export" / Path(src.path).name, overwrite=True)
        print("escrito", Path(src.path).name)


if __name__ == "__main__":
    main()
